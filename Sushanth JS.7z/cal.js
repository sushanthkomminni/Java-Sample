function doSum(){
              var x=document.getElementById('fv').value;
			  var y=document.getElementById('sv').value;
			  var result=parseInt(x)+parseInt(y);
			  document.write("sum is:"+result);
}
function doSub(){
              var x=document.getElementById('fv').value;
			  var y=document.getElementById('sv').value;
			  var result=parseInt(x)-parseInt(y);
			  document.write("sub is:"+result);
}