function validate()
{
  var a=document.getElementById('user').value;
     var reg1= /^[a-zA-Z0-9]{4,9}$/;
        var b=document.getElementById('mail').value;
	      var reg2=/^[a-zA-Z0-9]+[@][0-9a-zA-Z]+[.][a-zA-Z]+$/;
		    var c=document.getElementById('pass').value;
		       var reg3=/^(?=.*[0-9])(?=.*[a-z])(?=.*[_@#])(?=.*[A-Z]).{8,}$/;
	              var d=document.getElementById('conf').value;
		            var e=document.getElementById('mobi').value;
		              var reg5= /^[6-9][0-9]{9}$/; 
		                if(a.match(reg1))
			             {
				           document.getElementById('uerror').innerHTML="";
			              }		
					     else{
						      document.getElementById('uerror').innerHTML="<b style='color:red'>Invalid name</b>";
							  }   	
							    if(b.match(reg2))
							     {
								   document.getElementById('merror').innerHTML="";
							      }
							       else
							       {
								     document.getElementById('merror').innerHTML="<b style='color:red'>Invalid gmail</b>";
								   }
		
							if(c.match(reg3))
							{
								document.getElementById('perror').innerHTML="";
							}
							else
							{
								 document.getElementById('perror').innerHTML="<b style='color:red'>Invalid password</b>";
							}
							
		                    if(c==d)
							{
								document.getElementById('miserror').innerHTML="<b style='color:green'>password matched</b>";
							}
							else
							{
								 document.getElementById('miserror').innerHTML="<b style='color:red'>Invalid password</b>";
							}
                             if(e.match(reg5))
			                  {
				               document.getElementById('moerror').innerHTML="";
			                    }		
					            else{
						             document.getElementById('moerror').innerHTML="<b style='color:red'>Invalid number</b>";
							          }							
							
							
}
