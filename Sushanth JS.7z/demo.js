document.write("hello world!");
function replaceParaText(){
	 document.getElementById('para1').innerHTML="Hi, Good Morning";
}