package com.cg.mobile.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.mobile.bean.Mobile;
import com.cg.mobile.service.IMobileService;
import com.cg.mobile.service.MobileServiceImpl;

public class MobileUI {

	public static void main(String[] args) {
		IMobileService service =new MobileServiceImpl();
		//Mobile m =service.getMobileByPrice(2000);
		//System.out.println(service.display());
		
		Scanner sc =new Scanner(System.in);
		while(true)
		{
			System.out.println("1.insert");
			System.out.println("2.update");
			System.out.println("3. view");
			System.out.println("4.delete");
			System.out.println("search");
			System.out.println("exit");
			System.out.println("enter your option");
			int opt=sc.nextInt();
			switch(opt)
			{
			case 1:
				
				//int id1=sc.nextInt();
				//List<Mobile> list4=service.MobileAvailability(id1);
				break;
			case 2:
				//double price=sc.nextDouble();
				List<Mobile> list4=service.UpdateMobiles();
			for(Mobile m1: list4)
			{		
			System.out.println("id :"+m1.getMobileId());
			System.out.println("name :"+m1.getName());
			System.out.println("price :"+m1.getPrice());
			System.out.println("id :"+m1.getQuantity());
			System.out.println("----------------------");

		}
				
				
				
				
				break;
			case 3:
			//	System.out.println("enter price");
				//double price=sc.nextDouble();
				List<Mobile> list2=service.getAllMobiles();
			for(Mobile m1: list2)
			{		
			System.out.println("id :"+m1.getMobileId());
			System.out.println("name :"+m1.getName());
			System.out.println("price :"+m1.getPrice());
			System.out.println("id :"+m1.getQuantity());
			System.out.println("----------------------");

		}break;
			case 4:
				System.out.println("enter mobileId");
				int id=sc.nextInt();
				List<Mobile> list3=service.delMobileByPrice(id);
			for(Mobile m2: list3)
			{		
			System.out.println("id :"+m2.getMobileId());
			System.out.println("name :"+m2.getName());
			System.out.println("price :"+m2.getPrice());
			System.out.println("id :"+m2.getQuantity());
			}
				break;
			case 5:
			System.out.println("enter price");
				double price=sc.nextDouble();
				List<Mobile> list=service.getMobileByPrice(price);
			for(Mobile m1: list)
			{		
			System.out.println("id :"+m1.getMobileId());
			System.out.println("name :"+m1.getName());
			System.out.println("price :"+m1.getPrice());
			System.out.println("id :"+m1.getQuantity());

		}
			break;
			case 6: break;
			
			}
			
			
		}
			
			
		

}
}
