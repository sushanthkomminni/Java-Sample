package com.cg.mobile.service;

import java.util.List;

import com.cg.mobile.bean.Mobile;
import com.cg.mobile.dao.ImobileDao;
import com.cg.mobile.dao.ImobileDaoImpl;

public class MobileServiceImpl implements IMobileService {
	
	
	ImobileDao dao=new ImobileDaoImpl();

	
	@Override
	public  List<Mobile>  getMobileByPrice(double price)
	{
		return  (List<Mobile>) dao.getMobileByPrice(price);
	}
	
	public  List<Mobile>  getAllMobiles()
	{
		return  (List<Mobile>) dao.getAllMobiles();
	}
	
	public  List<Mobile>  delMobileByPrice(int id)
	{
		return  (List<Mobile>) dao.delMobileByPrice(id);
	}

	public  List<Mobile> UpdateMobiles()
	{
		return  (List<Mobile>) dao.UpdateMobiles();
	}

	
}
