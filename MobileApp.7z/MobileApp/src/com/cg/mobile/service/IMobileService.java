package com.cg.mobile.service;

import java.util.List;

import com.cg.mobile.bean.Mobile;



public interface IMobileService {
	//ImobileDaoImpl dao=new ImobileDao();
	//public String display();
	public  List<Mobile>  getMobileByPrice(double price);
	public  List<Mobile>  getAllMobiles();
	public  List<Mobile>  delMobileByPrice(int id);
	//public  List<Mobile>  MobileAvailability(int id1);
	//public  List<Mobile> UpdateMobiles();
	public List<Mobile> UpdateMobiles();
}
