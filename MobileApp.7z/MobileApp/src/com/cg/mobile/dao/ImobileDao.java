package com.cg.mobile.dao;

import java.util.List;

import com.cg.mobile.bean.Mobile;

public interface ImobileDao {
	public String display();
	//public Mobile   getMobileById(int mobileId);
	public  List<Mobile> getMobileByPrice(double price);
	public List<Mobile> getAllMobiles();
	public List<Mobile> delMobileByPrice(int id);
	public  List<Mobile> UpdateMobiles();
}
