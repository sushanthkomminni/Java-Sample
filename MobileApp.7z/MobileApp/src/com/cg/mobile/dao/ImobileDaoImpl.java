package com.cg.mobile.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.cg.mobile.bean.Mobile;

public class ImobileDaoImpl implements ImobileDao {

	 @Override
	public String display(){
		return "demo";
	 }	
		
		public  List<Mobile>  getMobileByPrice(double price)
		{
			try{
			 Class.forName("oracle.jdbc.driver.OracleDriver");
			 String url= "jdbc:oracle:thin:@localhost:1521:XE";
			 String user ="system";
			 String pass ="root";
			 Connection con=DriverManager.getConnection(url,"system","Capgemini123");
			 String sql="select *from mobiles  where price >=?";
			 PreparedStatement ps=con.prepareStatement(sql);
			 ps.setDouble(1,price);
			 ResultSet rs=ps.executeQuery();
			 Mobile m=null;
			 List<Mobile> list=new ArrayList<>();
			 while(rs.next())
			 {
				 m=new Mobile();
				 m.setMobileId(rs.getInt(1));
				 m.setName(rs.getString(2));
				 m.setPrice(rs.getDouble(3));
				 m.setQuantity(rs.getString(4));
				 list.add(m);
				 
			 }
			 return  list;
		}catch(Exception e)
			{
			   System.out.println(e);
			}
			return null;
			

		}
		
		
		public  List<Mobile>  getAllMobiles()
		{
			try{
			 Class.forName("oracle.jdbc.driver.OracleDriver");
			 String url= "jdbc:oracle:thin:@localhost:1521:XE";
			 String user ="system";
			 String pass ="Capgemini123";
			 Connection con=DriverManager.getConnection(url,"system","Capgemini123");
			 String sql="select * from mobiles";
			 PreparedStatement ps=con.prepareStatement(sql);
			 ResultSet rs=ps.executeQuery();
			 Mobile m=null;
			 List<Mobile> list2=new ArrayList<>();
			 while(rs.next())
			 {
				 m=new Mobile();
				 m.setMobileId(rs.getInt(1));
				 m.setName(rs.getString(2));
				 m.setPrice(rs.getDouble(3));
				 m.setQuantity(rs.getString(4));
				 list2.add(m);
				 
			 }
			 return  list2;
		}catch(Exception e)
			{
			   System.out.println(e);
			}
			return null;			
			
}
		public  List<Mobile>  delMobileByPrice(int id)
		{
			try{
			 Class.forName("oracle.jdbc.driver.OracleDriver");
			 String url= "jdbc:oracle:thin:@localhost:1521:XE";
			 String user ="system";
			 String pass ="root";
			 Connection con=DriverManager.getConnection(url,"system","Capgemini123");
			 String sql="delete from mobiles  where price >=?";
			 PreparedStatement ps=con.prepareStatement(sql);
			 ps.setInt(1,id);
			 ps.executeQuery();
			 String sql1="select * from mobiles";
			 PreparedStatement ps1=con.prepareStatement(sql1);
			
			 ResultSet rs1=ps1.executeQuery();
			 Mobile m1=null;
			 List<Mobile> list3=new ArrayList<>();
			 while(rs1.next())
			 {
				 m1=new Mobile();
				 m1.setMobileId(rs1.getInt(1));
				 m1.setName(rs1.getString(2));
				 m1.setPrice(rs1.getDouble(3));
				 m1.setQuantity(rs1.getString(4));
				 list3.add(m1);
				 
			 }
			 return  list3;
		}catch(Exception e)
			{
			   System.out.println(e);
			}
			return null;			
			
}
		
		public  List<Mobile> UpdateMobiles()
		{
			try{
				 Class.forName("oracle.jdbc.driver.OracleDriver");
				 String url= "jdbc:oracle:thin:@localhost:1521:XE";
				 String user ="system";
				 String pass ="Capgemini123";
				 Connection con=DriverManager.getConnection(url,"system","Capgemini123");
				 String sql="select * from mobiles";
				 PreparedStatement ps=con.prepareStatement(sql);
				 ResultSet rs=ps.executeQuery();
				 Mobile m=null;
				 List<Mobile> list4=new ArrayList<>();
				 while(rs.next())
				 {
					 m=new Mobile();
					 m.setMobileId(rs.getInt(1));
					 m.setName(rs.getString(2));
					 m.setPrice(rs.getDouble(3));
					 m.setQuantity(rs.getString(4));
					 list4.add(m);
					 
				 }
				 return  list4;
			}catch(Exception e)
				{
				   System.out.println(e);
				}
				return null;			
				
	}
		
		
		
}
