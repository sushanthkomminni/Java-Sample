package com.capgemini.contactbook.dao.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.ContactBookException;
//import com.capgemini.contactbook.exceptions.ContactBookException;
import com.igate.contactbook.bean.EnquiryBean;
public class ContactBookDaoImplTest {
	ContactBookDaoImpl dao = null;

	@Before
	public void setUp() {
	dao = new ContactBookDaoImpl();
	}

	@After
	public void tearDown() {
	dao = null;
	}

	@Test
	public void addEnquiry() throws ContactBookException {
	EnquiryBean addEnquiryDetails = new EnquiryBean();
	addEnquiryDetails.setfName("Sushanth");
	addEnquiryDetails.setlName("Kumar");
	addEnquiryDetails.setContactNo("9290040680");
	addEnquiryDetails.setpDomain("Java");
	addEnquiryDetails.setpLocation("Hyderabad");
	Integer enqryId = dao.addEnquiry(addEnquiryDetails);
	assertNotNull(enqryId);
	//System.out.println("Successfully proved the Test Case for Adding Details.");

//	System.err.println("Test Case failed for Adding Details");
	}
	@Test
	public void getEnquiryDetails() throws ContactBookException {
	EnquiryBean searchEnquiry;

	searchEnquiry = dao.getEnquiryDetails(1007);
	assertEquals("Sushanth", searchEnquiry.getfName());
	//System.out.println("Successfully proved the Test Case for Search Operation.");

	} 
	}
	


