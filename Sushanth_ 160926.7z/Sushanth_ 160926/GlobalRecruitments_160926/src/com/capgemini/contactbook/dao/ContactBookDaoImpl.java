package com.capgemini.contactbook.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.utility.JdbcUtility;

import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookDaoImpl implements ContactBookDao {
	
	Connection connection = null;
	PreparedStatement statement = null;
	static Logger logger = Logger.getLogger(ContactBookDaoImpl.class);
	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws ContactBookException {//searching enquiry details by taking enquiry id and getting the details
		logger.info("in getting  for enquiry details  mehtod..");

		connection = JdbcUtility.getConnection();
		try {
			statement = connection
					.prepareStatement(QueryConstants.getDetails);//getting the details based on id
			statement.setInt(1, EnquiryID);
			ResultSet rs=null;
			
			 rs = statement.executeQuery();	
			
			rs.next();
			EnquiryBean eb1 = new EnquiryBean();

			eb1.setEnqryId(rs.getInt(1));
			eb1.setfName(rs.getString(2));
			eb1.setlName(rs.getString(3));
			eb1.setContactNo(Long.toString(rs.getLong(4)));
			eb1.setpDomain(rs.getString(5));
			eb1.setpLocation(rs.getString(6));

			return eb1;

		} catch (SQLException e) {
			logger.error("in enquiry details method ex is: " + e.getMessage());
			throw new ContactBookException(" sorry no details found");
		}

		
		
	}

	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException //searching the database based on enquiry id
 	{
		
		logger.info("in add patient  deatils  method..");
		connection = JdbcUtility.getConnection();

		try {
			statement = connection.prepareStatement(QueryConstants.insertQuery);//inserting the query based on insert query
			statement.setString(1, enqry.getfName());
			statement.setString(2, enqry.getlName());
			statement.setLong(3, Long.parseLong(enqry.getContactNo()));//parsing the contact number because we took the contact number in string
			statement.setString(4, enqry.getpDomain());
			statement.setString(5, enqry.getpLocation());
            statement.executeUpdate();
			statement = connection.prepareStatement(QueryConstants.getIdQuery);
			ResultSet rs = statement.executeQuery();//execute the query
			rs.next();
			int id=rs.getInt(1);
			return id;//returning the id

		} catch (SQLException e) {
			logger.error("statement not created..");
			e.printStackTrace();
			throw new ContactBookException("statement not created");

		}


		
	}
	
	

}
